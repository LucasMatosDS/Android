package matos.lucas.aula01_android_java;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.widget.EditText;

public class act_cad_cliente extends AppCompatActivity {

    private EditText nome;
    private EditText endereco;
    private EditText email;
    private EditText contato;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_act_cad_cliente);
        inicializacao();
    }

    public void returnView(View v){
        Intent it = new Intent(act_cad_cliente.this, MainActivity.class);
        startActivity(it);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_act_cad_cliente, menu);
        return super.onCreateOptionsMenu(menu);
    }

    public void inicializacao(){
         nome = findViewById(R.id.edit_nome);
         endereco = findViewById(R.id.edit_endereco);
         email = findViewById(R.id.edit_endereco);
         contato = findViewById(R.id.editContato);
    }
}